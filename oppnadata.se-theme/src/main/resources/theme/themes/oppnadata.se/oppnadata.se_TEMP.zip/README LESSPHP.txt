LESSPHP seems to have a bug regading the compilation of @media-tags, which we need for the responsive design. 
The inluded commandline tool does however work. 
Using this as a _temporary_ solution for development.

To run it just add your [PHP_INSTALL_DIR]\bin to your path and run plessc\run.bat
This will start a watchdog udating when any changes are made in the theme.
