<?php


function rapidresponse_preprocess_node(&$vars) {


  // $variables['node'] = $variables['elements']['#node'];
  // $node = $variables['node'];

  // $variables['date']      = format_date($node->created);

  // // Make the field variables available with the appropriate language.
  // field_attach_preprocess('node', $node, $variables['content'], $variables);

  // // Gather node classes.
  // $variables['classes_array'][] = drupal_html_class('node-' . $node->type);

    $vars['bepa'] = 'kalle';

}

